import sys

def sqlify(keyColumn, data, how='', item='key', condition='=', raiseException=True):
    try:
        if not isinstance(keyColumn, str) or not keyColumn.strip():
            raise ValueError("keyColumn must be a non-empty string.")

        if item not in ('key', 'value'):
            raise ValueError("Invalid value for 'item'. Expected 'key' or 'value'.")

        if not isinstance(raiseException, bool):
            raise ValueError("raiseException must be a boolean (True or False).")

        valid_conditions = {'=', '!=', '>', '<', '>=', '<=', 'LIKE', 'NOT LIKE'}
        if condition not in valid_conditions:
            error_msg = f"Invalid condition '{condition}'. Allowed values: {valid_conditions}"
            if raiseException:
                raise ValueError(error_msg)
            else:
                import logging
                logging.error(error_msg)
                return ''

        if not isinstance(data, (int, str, dict, list, tuple, set)):
            error_msg = "Invalid data type. Expected int, str, dict, list, tuple, or set."
            if raiseException:
                raise ValueError(error_msg)
            else:
                import logging
                logging.error(error_msg)
                return ''

        if isinstance(data, str):
            data = (data,) if data.strip() else ()
        elif isinstance(data, int):
            data = (data,)
        elif isinstance(data, (list, set, tuple)):
            data = tuple(data)
        elif isinstance(data, dict):
            data = tuple(data.keys()) if item == 'key' else tuple(data.values())

        if not data:
            return ''

        condition_type = how.upper().strip() if how else ''

        if len(data) == 1:
            value = f"'{data[0]}'" if isinstance(data[0], str) else data[0]
            return f"{condition_type} {keyColumn} {condition} {value}".strip() if condition_type else f"{keyColumn} {condition} {value}"
        else:
            formatted_values = ', '.join(f"'{v}'" if isinstance(v, str) else str(v) for v in data)
            return f"{condition_type} {keyColumn} IN ({formatted_values})".strip() if condition_type else f"{keyColumn} IN ({formatted_values})"

    except Exception as e:
        import logging
        logging.error(f"Error in sqlify: {e}")
        return '' if not raiseException else sys.exit(1)

def sqlifylike(keyColumn, data, how='', wildcard='%{}%', joiner='OR', raiseException=True):
    try:
        if not isinstance(keyColumn, str) or not keyColumn.strip():
            raise ValueError("keyColumn must be a non-empty string.")

        if not isinstance(raiseException, bool):
            raise ValueError("raiseException must be a boolean (True or False).")

        if not isinstance(data, (str, list, tuple, set)):
            error_msg = "Invalid data type. Expected str, list, tuple, or set."
            if raiseException:
                raise ValueError(error_msg)
            else:
                import logging
                logging.error(error_msg)
                return ''

        if isinstance(data, str):
            data = (data,) if data.strip() else ()
        elif isinstance(data, (list, set, tuple)):
            data = tuple(data)

        if not data:
            return ''

        condition_type = how.upper().strip() if how else ''
        conditions = [f"{keyColumn} LIKE '{wildcard.replace('{}', str(value))}'" for value in data]
        sql_condition = f" {joiner} ".join(conditions)

        return f"{condition_type} ({sql_condition})" if condition_type else f"({sql_condition})"

    except Exception as e:
        import logging
        logging.error(f"Error in sqlifylike: {e}")
        return '' if not raiseException else sys.exit(1)
