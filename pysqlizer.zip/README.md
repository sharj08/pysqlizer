# pysqlizer

pysqlizer is a Python library for dynamically generating SQL queries efficiently.

## Installation

```sh
pip install pysqlizer
```

## Usage

```python
from pysqlizer.sql_generator import sqlify, sqlifylike

# Example Usage
print(sqlify('id', [1, 2, 3], how='WHERE'))
print(sqlifylike('name', ['John', 'Doe'], how='WHERE', wildcard='%{}%'))
```

## License

MIT License
