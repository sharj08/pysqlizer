from setuptools import setup, find_packages

setup(
    name='pysqlizer',
    version='1.0.0',
    author='Akash Kushwaha',
    author_email='sing.akash081998@gmail.com',
    description='A Python library for dynamically generating SQL queries.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
